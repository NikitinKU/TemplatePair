using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace ImageProcessing
{
    public partial class Form1 : Form
    {
        Bitmap image1;
        Bitmap image2;
        public Form1()
        {
            InitializeComponent();
        }

        private void firstImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image files | *.png; *.jpg; *.bmp | All files (*.*) | *.*";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                image1 = new Bitmap(dialog.FileName);
                pictureBox1.Image = image1;
                pictureBox1.Refresh();
            }
        }

        private void secondImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image files | *.png; *.jpg; *.bmp | All files (*.*) | *.*";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                image2 = new Bitmap(dialog.FileName);
                pictureBox2.Image = image2;
                pictureBox2.Refresh();
            }
        }

        static double MSE_calcuate(Bitmap image1, Bitmap image2)
        {
            int width = image1.Width;
            int height = image1.Height;
            double mse = 0;

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Color pixelImage1 = image1.GetPixel(i, j);
                    Color pixelImage2 = image2.GetPixel(i, j);

                    double redError = pixelImage1.R - pixelImage2.R;
                    double greenError = pixelImage1.G - pixelImage2.G;
                    double blueError = pixelImage1.B - pixelImage2.B;

                    double pixelError = (redError * redError) + (greenError * greenError) + (blueError * blueError);
                    mse += pixelError;
                }
            }

            mse /= (width * height * 3);
            return mse;
        }

        static double UQI_calcuate(Bitmap image1, Bitmap image2)
        {
            int width = image1.Width;
            int height = image1.Height;
            int totalPixels = width * height;
            // ��������� ��� ������������ ������� �� ����
            double C1 = 6.5025;
            double C2 = 58.5225;

            // ������� �������� ������� �������� ���� ����������� (x & y ����������)
            double avr_brightnessX = 0;
            double avr_brightnessY = 0;

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    avr_brightnessX += image1.GetPixel(i, j).R;
                    avr_brightnessY += image2.GetPixel(i, j).R;
                }
            }

            avr_brightnessX /= totalPixels;
            avr_brightnessY /= totalPixels;

            // ���������� ������� �������� ���� �����������
            double deviationX = 0;
            double deviationY = 0;
            // ���������� ����� �������� �������� ���� �����������
            double covarianceXY = 0;

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    int x = image1.GetPixel(i, j).R;
                    int y = image2.GetPixel(i, j).R;

                    double diffX = x - avr_brightnessX;
                    double diffY = y - avr_brightnessY;
                    deviationX += diffX * diffX;
                    deviationY += diffY * diffY;
                    covarianceXY += diffX * diffY;
                }
            }

            deviationX = Math.Sqrt(deviationX / totalPixels);
            deviationY = Math.Sqrt(deviationY / totalPixels);
            covarianceXY /= totalPixels;

            double qualityIndex =
                (covarianceXY / (deviationX * deviationY)) *
                ((2 * avr_brightnessX * avr_brightnessY + C1) / (avr_brightnessX * avr_brightnessX + avr_brightnessY * avr_brightnessY + C1)) *
                ((2 * deviationX * deviationY + C2) / (deviationX * deviationX + deviationY * deviationY + C2));

            return qualityIndex;
        }

      

        public static List<Bitmap> ImageSplitting(int width, int height, Bitmap inputImage)
        {
            int blockWidth = inputImage.Width / width;
            int blockHeight = inputImage.Height / height;

            List<Bitmap> outputImages = new List<Bitmap>();

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Rectangle destRect = new Rectangle(0, 0, blockWidth, blockHeight);
                    Bitmap block = new Bitmap(blockWidth, blockHeight);
                    using (Graphics g = Graphics.FromImage(block))
                    {
                        Rectangle srcRect = new Rectangle(j * blockWidth, i * blockHeight, blockWidth, blockHeight);
                        g.DrawImage(inputImage, destRect, srcRect, GraphicsUnit.Pixel);
                    }
                    outputImages.Add(block);
                }
            }

            return outputImages;
        }

        /*public static Bitmap GaussianFilter(Bitmap image)
        {
            int width = image.Width;
            int height = image.Height;

            BitmapData image_data = image.LockBits(
            new Rectangle(0, 0, width, height),
            ImageLockMode.ReadOnly,
            PixelFormat.Format24bppRgb);
            int bytes = image_data.Stride * image_data.Height;
            byte[] buffer = new byte[bytes];
            byte[] result = new byte[bytes];
            Marshal.Copy(image_data.Scan0, buffer, 0, bytes);
            image.UnlockBits(image_data);

            byte[] noise = new byte[bytes];
            double[] gaussian = new double[256];
            int std = 20;
            Random rnd = new Random();
            double sum = 0;
            for (int i = 0; i < 256; i++)
            {
                gaussian[i] = (double)((1 / (Math.Sqrt(2 * Math.PI) * std)) *
                    Math.Exp(-Math.Pow(i, 2) / (2 * Math.Pow(std, 2))));
                sum += gaussian[i];
            }

            for (int i = 0; i < 256; i++)
            {
                gaussian[i] /= sum;
                gaussian[i] *= bytes;
                gaussian[i] = (int)Math.Floor(gaussian[i]);
            }

            int count = 0;
            for (int i = 0; i < 256; i++)
            {
                for (int j = 0; j < (int)gaussian[i]; j++)
                {
                    noise[j + count] = (byte)i;
                }
                count += (int)gaussian[i];
            }

            for (int i = 0; i < bytes - count; i++)
            {
                noise[count + i] = 0;
            }

            noise = noise.OrderBy(x => rnd.Next()).ToArray();

            for (int i = 0; i < bytes; i++)
            {
                result[i] = (byte)(buffer[i] + noise[i]);
            }

            Bitmap result_image = new Bitmap(width, height);
            BitmapData result_data = result_image.LockBits(
                new Rectangle(0, 0, width, height),
                ImageLockMode.WriteOnly,
                PixelFormat.Format24bppRgb);
            Marshal.Copy(result, 0, result_data.Scan0, bytes);
            result_image.UnlockBits(result_data);
            return result_image;
        }*/

        static Bitmap GaussianNoise(Bitmap image, double stdDev)
        {
            Bitmap noisyImage = new Bitmap(image.Width, image.Height);
            Random rand = new Random();

            for (int x = 0; x < image.Width; x++)
            {
                for (int y = 0; y < image.Height; y++)
                {
                    Color pixel = image.GetPixel(x, y);

                    int r = Clamp(pixel.R + (int)(NextGaussian(rand) * stdDev + 0.5), 0, 255);
                    int g = Clamp(pixel.G + (int)(NextGaussian(rand) * stdDev + 0.5), 0, 255);
                    int b = Clamp(pixel.B + (int)(NextGaussian(rand) * stdDev + 0.5), 0, 255);

                    noisyImage.SetPixel(x, y, Color.FromArgb(pixel.A, r, g, b));
                }
            }

            return noisyImage;
        }
        static int Clamp(int value, int min, int max)
        {
            if (value < min) return min;
            if (value > max) return max;
            return value;
        }

        public static double NextGaussian(Random rand, double mean = 0, double stdDev = 1)
        {
            double u1 = 1.0 - rand.NextDouble();
            double u2 = 1.0 - rand.NextDouble();
            double randStdNormal = Math.Sqrt(-2.0 * Math.Log(u1)) * Math.Sin(2.0 * Math.PI * u2);
            return mean + stdDev * randStdNormal;
        }

        private void mSEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (image1.Width != image2.Width || image1.Height != image2.Height)
            {
                label1.Text = "MSE: err size!";
                return;
            }

            double mse = MSE_calcuate(image1, image2);
            label1.Text = "MSE: \t" + mse.ToString();
        }

        private void uQIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (image1.Width != image2.Width || image1.Height != image2.Height)
            {
                label2.Text = "UQI average: err size!";
                return;
            }

            double uqi = UQI_calcuate(image1, image2);
            label2.Text = "UQI: \t" + uqi.ToString();
        }

        private void mSEAverageRateToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (image1.Width != image2.Width || image1.Height != image2.Height)
            {
                label3.Text = "MSE average: err size!";
                return;
            }

            int height = 3;
            int width = 3;
            List<Bitmap> listImage1 = ImageSplitting(width, height, image1);
            List<Bitmap> listImage2 = ImageSplitting(width, height, image2);
            double sum = 0;
            for (int i = 0; i < width * height; i++)
            {
                sum += MSE_calcuate(listImage1[i], listImage2[i]);
            }

            label3.Text = "MSE average: \t" + (sum / (width * height)).ToString();
        }

        private void uQIAverageRateToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (image1.Width != image2.Width || image1.Height != image2.Height)
            {
                label4.Text = "UQI average: err size!";
                return;
            }

            int height = 3;
            int width = 3;
            List<Bitmap> listImage1 = ImageSplitting(width, height, image1);
            List<Bitmap> listImage2 = ImageSplitting(width, height, image2);
            double sum = 0;
            for (int i = 0; i < width * height; i++)
            {
                sum += UQI_calcuate(listImage1[i], listImage2[i]);
            }

            label4.Text = "UQI average: \t" + (sum / (width * height)).ToString();
        }

        private void gaussianNoiseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bitmap image2 = GaussianNoise(image2, 50);
            image1 = image2;
            pictureBox2.Image = image2;
            pictureBox2.Refresh();
            //Bitmap NoisyImage = GaussianNoise(image1);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }


    }
}