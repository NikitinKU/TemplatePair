﻿namespace ImageProcessing
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imageInputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.firstImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.secondImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.processorsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mSEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mSEAverageRateToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.uQIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uQIAverageRateToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.noiseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filtersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gaussianNoiseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(661, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.imageInputToolStripMenuItem,
            this.processorsToolStripMenuItem,
            this.noiseToolStripMenuItem,
            this.filtersToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // imageInputToolStripMenuItem
            // 
            this.imageInputToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstImageToolStripMenuItem,
            this.secondImageToolStripMenuItem});
            this.imageInputToolStripMenuItem.Name = "imageInputToolStripMenuItem";
            this.imageInputToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.imageInputToolStripMenuItem.Text = "Image input";
            // 
            // firstImageToolStripMenuItem
            // 
            this.firstImageToolStripMenuItem.Name = "firstImageToolStripMenuItem";
            this.firstImageToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.firstImageToolStripMenuItem.Text = "First image";
            this.firstImageToolStripMenuItem.Click += new System.EventHandler(this.firstImageToolStripMenuItem_Click);
            // 
            // secondImageToolStripMenuItem
            // 
            this.secondImageToolStripMenuItem.Name = "secondImageToolStripMenuItem";
            this.secondImageToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.secondImageToolStripMenuItem.Text = "Second image";
            this.secondImageToolStripMenuItem.Click += new System.EventHandler(this.secondImageToolStripMenuItem_Click);
            // 
            // processorsToolStripMenuItem
            // 
            this.processorsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mSEToolStripMenuItem,
            this.mSEAverageRateToolStripMenuItem1,
            this.uQIToolStripMenuItem,
            this.uQIAverageRateToolStripMenuItem1});
            this.processorsToolStripMenuItem.Name = "processorsToolStripMenuItem";
            this.processorsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.processorsToolStripMenuItem.Text = "Processors";
            // 
            // mSEToolStripMenuItem
            // 
            this.mSEToolStripMenuItem.Name = "mSEToolStripMenuItem";
            this.mSEToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.mSEToolStripMenuItem.Text = "MSE";
            this.mSEToolStripMenuItem.Click += new System.EventHandler(this.mSEToolStripMenuItem_Click);
            // 
            // mSEAverageRateToolStripMenuItem1
            // 
            this.mSEAverageRateToolStripMenuItem1.Name = "mSEAverageRateToolStripMenuItem1";
            this.mSEAverageRateToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.mSEAverageRateToolStripMenuItem1.Text = "MSE (Average Rate)";
            this.mSEAverageRateToolStripMenuItem1.Click += new System.EventHandler(this.mSEAverageRateToolStripMenuItem1_Click);
            // 
            // uQIToolStripMenuItem
            // 
            this.uQIToolStripMenuItem.Name = "uQIToolStripMenuItem";
            this.uQIToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.uQIToolStripMenuItem.Text = "UQI";
            this.uQIToolStripMenuItem.Click += new System.EventHandler(this.uQIToolStripMenuItem_Click);
            // 
            // uQIAverageRateToolStripMenuItem1
            // 
            this.uQIAverageRateToolStripMenuItem1.Name = "uQIAverageRateToolStripMenuItem1";
            this.uQIAverageRateToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.uQIAverageRateToolStripMenuItem1.Text = "UQI (Average Rate)";
            this.uQIAverageRateToolStripMenuItem1.Click += new System.EventHandler(this.uQIAverageRateToolStripMenuItem1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 149);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 300);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(349, 149);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(300, 300);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "MSE Processing :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "UQI Processing :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "MSE (Average Rate) :";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "UQI (Average Rate) :";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(661, 461);
            this.panel1.TabIndex = 7;
            // 
            // noiseToolStripMenuItem
            // 
            this.noiseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gaussianNoiseToolStripMenuItem});
            this.noiseToolStripMenuItem.Name = "noiseToolStripMenuItem";
            this.noiseToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.noiseToolStripMenuItem.Text = "Noise";
            // 
            // filtersToolStripMenuItem
            // 
            this.filtersToolStripMenuItem.Name = "filtersToolStripMenuItem";
            this.filtersToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.filtersToolStripMenuItem.Text = "Filters";
            // 
            // gaussianNoiseToolStripMenuItem
            // 
            this.gaussianNoiseToolStripMenuItem.Name = "gaussianNoiseToolStripMenuItem";
            this.gaussianNoiseToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.gaussianNoiseToolStripMenuItem.Text = "Gaussian noise";
            this.gaussianNoiseToolStripMenuItem.Click += new System.EventHandler(this.gaussianNoiseToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 461);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem imageInputToolStripMenuItem;
        private ToolStripMenuItem firstImageToolStripMenuItem;
        private ToolStripMenuItem secondImageToolStripMenuItem;
        private ToolStripMenuItem processorsToolStripMenuItem;
        private ToolStripMenuItem mSEToolStripMenuItem;
        private ToolStripMenuItem uQIToolStripMenuItem;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private ToolStripMenuItem mSEAverageRateToolStripMenuItem1;
        private ToolStripMenuItem uQIAverageRateToolStripMenuItem1;
        private Panel panel1;
        private ToolStripMenuItem noiseToolStripMenuItem;
        private ToolStripMenuItem gaussianNoiseToolStripMenuItem;
        private ToolStripMenuItem filtersToolStripMenuItem;
    }
}